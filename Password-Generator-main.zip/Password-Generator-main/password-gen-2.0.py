import random
from art import *
from RandomWordGenerator import RandomWord

rw = RandomWord(max_word_size=15,
                constant_word_size=True,
                special_chars=r"",
                include_special_chars=True)


tprint(rw.generate())